Regex_Pattern = r"(.)(?!\1)"	# Do not delete 'r'.
