Regex_Pattern = r"(?<![aeiouAEIOU])."	# Do not delete 'r'.
