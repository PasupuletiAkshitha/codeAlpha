Regex_Pattern = r'o(?=oo)'	# Do not delete 'r'.
