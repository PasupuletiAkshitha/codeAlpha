Regex_Pattern = r"(?<=[1,3,5,7,9])\d"	# Do not delete 'r'.
