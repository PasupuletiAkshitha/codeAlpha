Regex_Pattern = r'^[^0-9][^aeiou][^bcDF][^\r\n\t\f\s][^AEIOU][^\.,]$'	# Do not delete 'r'.
