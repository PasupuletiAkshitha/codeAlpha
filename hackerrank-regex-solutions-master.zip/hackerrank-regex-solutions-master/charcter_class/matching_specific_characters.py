Regex_Pattern = r'^[123][120][xs0][30Aa][sxu][\.,]$'	# Do not delete 'r'.
