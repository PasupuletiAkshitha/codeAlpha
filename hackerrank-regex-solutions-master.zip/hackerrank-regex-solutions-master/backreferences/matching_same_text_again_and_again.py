Regex_Pattern = r'^([a-z])([a-zA-Z_])(\s)([^a-zA-Z])(\d)(\D)([A-Z])([a-zA-Z])([aeiouAEIOU])(\S)\1\2\3\4\5\6\7\8\9\10$'	# Do not delete 'r'.
