#PHP solution

$Regex_Pattern = '/^\d{2}(?|(-)|(---)|(\.)|(\:))\d{2}\1\d{2}\1\d{2}$/'; //Do not delete '/'. Replace __________ with your regex. 
