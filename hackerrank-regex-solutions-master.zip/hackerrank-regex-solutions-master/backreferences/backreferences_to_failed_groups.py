Regex_Pattern = r"^\d{2}(-?)\d{2}\1\d{2}\1\d{2}$"	# Do not delete 'r'.
