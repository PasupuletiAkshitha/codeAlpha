Regex_Pattern = r'(ok){3,}'	# Do not delete 'r'.
