Regex_Pattern = r'^\d{1,2}[a-zA-Z]{3,}\.{,3}$'	# Do not delete 'r'.
