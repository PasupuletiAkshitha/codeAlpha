Regex_Pattern = r'^[a-zA-Z]*s$'	# Do not delete 'r'.
