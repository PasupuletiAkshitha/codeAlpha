Regex_Pattern = r'^\d+[A-Z]+[a-z]+$'	# Do not delete 'r'.
