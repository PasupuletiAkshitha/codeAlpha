Regex_Pattern = r"\w{3}\W\w+?\W\w{3}"	# Do not delete 'r'.
