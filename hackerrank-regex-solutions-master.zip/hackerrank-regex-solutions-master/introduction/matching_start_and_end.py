Regex_Pattern = r"^\d\w{4}\.$"	# Do not delete 'r'.

