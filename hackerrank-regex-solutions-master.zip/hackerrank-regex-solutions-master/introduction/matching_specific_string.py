Regex_Pattern = r'hackerrank'	# Do not delete 'r'.
