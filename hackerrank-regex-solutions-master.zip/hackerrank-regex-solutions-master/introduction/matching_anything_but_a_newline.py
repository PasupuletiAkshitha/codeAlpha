regex_pattern = r"...\....\....\....$"	# Do not delete 'r'.
