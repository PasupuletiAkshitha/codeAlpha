Regex_Pattern = r"\S{2}\s\S{2}\s\S{2}"	# Do not delete 'r'.

